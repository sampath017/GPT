package com.example.SBS_Practice1.configuration;

import com.example.SBS_Practice1.entity.appEntity.AppUser;
import com.example.SBS_Practice1.entity.appEntity.AppUserDetails;
import com.example.SBS_Practice1.repo.appRepo.AppUserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class CustomeUserDetailsServiceAppUser implements UserDetailsService {

    @Autowired
    AppUserRepo appUserRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        AppUser appUser=appUserRepo.findByUsername(username);
        if(appUser==null){
            throw new UsernameNotFoundException("App usernot fpound");
        }
       // AppUserDetails appUserDetails=new AppUserDetails(appUser);


        return new AppUserDetails(appUser);
    }
}

package com.example.SBS_Practice1.configuration;

import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.entity.Role;
import com.example.SBS_Practice1.entity.appEntity.AppoRole;
import com.example.SBS_Practice1.jwt_service.JwtFilter;
import com.example.SBS_Practice1.repo.MemberRepository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;

import org.springframework.security.core.userdetails.UserDetailsService;

import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;



@EnableWebSecurity
@EnableMethodSecurity
@Configuration
public class SecurityConfig {


    //  private static final Logger logger = LoggerFactory.getLogger(Config.SecurityConfig.class);
    @Autowired
    MemberRepository memberRepository;

    @Autowired
    JwtFilter jwtFilter;

    @Autowired
    CustomeUserDetailsServiceAppUser customeUserDetailsServiceAppUser;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                .csrf(AbstractHttpConfigurer::disable)
                .headers(h -> h.frameOptions(HeadersConfigurer.FrameOptionsConfig::disable))
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .authorizeHttpRequests(auth -> {
                            auth.requestMatchers("/register").permitAll();
                            auth.requestMatchers(HttpMethod.POST, "/login").permitAll();
                            auth.requestMatchers("/api/appUser/register").permitAll();
                            auth.requestMatchers("/api/appUser/login").permitAll();

                            auth.requestMatchers("path").permitAll();
                            auth.requestMatchers("/h2-console/**").permitAll();
                            auth.requestMatchers("/chief/get").hasRole(String.valueOf(Role.CHIEF));
                           // auth.requestMatchers("/player/update/**").hasAnyRole(String.valueOf(Role.CHIEF),String.valueOf(Role.STAFF),String.valueOf(Role.PLAYER));
                            auth.requestMatchers("/player/get/**").hasAnyRole(String.valueOf(Role.CHIEF),String.valueOf(Role.STAFF),String.valueOf(Role.PLAYER))
                                    .requestMatchers("/staff/**").hasRole(String.valueOf(Role.STAFF))
                                    .requestMatchers("/chief/**").hasRole(String.valueOf(Role.CHIEF))
                                    .requestMatchers("/api/patient/book/appointment").hasRole(AppoRole.PATIENT.name())
                                    .requestMatchers("/api/appointments/{id}/status").hasAnyRole(AppoRole.ADMIN.name(),AppoRole.DOCTOR.name())
                                    .requestMatchers("/api/appointments/delete/").hasAnyRole(AppoRole.ADMIN.name(),AppoRole.PATIENT.name())
                                    .requestMatchers("/api/doctors/**").hasAnyRole(AppoRole.ADMIN.name(),AppoRole.DOCTOR.name())
                                    .requestMatchers("/api/patients/**").hasAnyRole(AppoRole.ADMIN.name(),AppoRole.PATIENT.name())
                                    .anyRequest().authenticated();
                          //  auth.requestMatchers("/player/get/**").hasRole(String.valueOf(Role.PLAYER));

                        }
                );
      //  logger.info("Security configuration applied successfully");
        System.out.println("All configs are oaky");

        return http.build();
    }

    // produce a bean for userdetailsdervice
//    @Bean
//    UserDetailsService userDetailsService() {
//        return username -> {
//            System.out.println("UserD service method ");
//           // return  memberRepository.findByName
//            Member member=memberRepository.findByName(username);
//            if(member==null){
//                throw new UsernameNotFoundException("Member not found");
//            }
//            return member;
//        };
//    }








    // we can write other way here ...


    @Bean
    PasswordEncoder passwordEncoder() {
        System.out.println("passwordEncoder method ");
        return new BCryptPasswordEncoder();
    }

    @Bean
    AuthenticationProvider daoAuthenticationProvider() {
        System.out.println("daoAuthenticationProvider method ");
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setUserDetailsService(customeUserDetailsServiceAppUser);
        auth.setPasswordEncoder(passwordEncoder());
        System.out.println("daoAuthenticationProvider method end");
        return auth;

    }


    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        System.out.println("authenticationManager method ");
        return config.getAuthenticationManager();
    }
}



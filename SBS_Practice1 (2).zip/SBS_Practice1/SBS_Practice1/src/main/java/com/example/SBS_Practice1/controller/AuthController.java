package com.example.SBS_Practice1.controller;


import com.example.SBS_Practice1.dto.Login;
import com.example.SBS_Practice1.dto.LoginResponse;
import com.example.SBS_Practice1.entity.Booking;
import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.entity.MemberNotFound;
import com.example.SBS_Practice1.jwt_service.JwtUtils;
import com.example.SBS_Practice1.repo.MemberRepository;
import com.example.SBS_Practice1.service.BookingService;
import com.example.SBS_Practice1.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;


@RestController
public class AuthController {

    @Autowired
    MemberService memberService;

    @Autowired
    BookingService bookingService;
    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    PasswordEncoder passwordEncoder;

     @Autowired
    MemberRepository memberRepository;

    @PostMapping("/register")
    public ResponseEntity<HashMap<String,String>> checkController(@RequestBody Member member){
        System.out.println("Inside registration");
        Member m=new Member();
        m.setId(member.getId());
        m.setName(member.getName());
        m.setAge(member.getAge());
        m.setPlayingRole(member.getPlayingRole());
        m.setStatus("Registered");
        m.setPassword(passwordEncoder.encode(member.getPassword()));
        m.setRole(member.getRole());
        System.out.println("Role:"+m.getRole());
        System.out.println("Controller : Inside registration");
        return memberService.save(m);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Login login){
        System.out.println("Username :"+login.getUsername());
        System.out.println("Password "+login.getPassword());

        LoginResponse loginResponse=new LoginResponse();

        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(login.getUsername(), login.getPassword()));
        }catch(Exception e){
            loginResponse.setStatus("Failed");
            loginResponse.setToken("No Token Generated due to Login Failure");
            return new ResponseEntity<>(loginResponse,HttpStatus.BAD_REQUEST);
        }
            Member member = memberRepository.findByName(login.getUsername());
            System.out.println("Password checp completes");
            if (member == null) {
                System.out.println("There is no data for user :" + login.getUsername());
                System.out.println("Login failed");
                loginResponse.setStatus("Failed");
                loginResponse.setToken("No Token Generated due to Login Failure");
                //return new ResponseEntity<>(loginResponse,HttpStatus.BAD_REQUEST);
                throw new MemberNotFound("Details not found due to some error");

            }
            // We will fetch the data by username after successful login
            String token = jwtUtils.generateToken(member);
            loginResponse.setStatus("Success");
            loginResponse.setToken(token);
            System.out.println("token"+token);
            return new ResponseEntity<>(loginResponse, HttpStatus.OK);
    }



    // Each member fetch the data by them self after login by id
    @GetMapping("/player/get/id") //working- but need conditions in it
    @PreAuthorize("hasRole('PLAYER')")
    public ResponseEntity<Member> getPlayerDetails(){

        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        Member memb=(Member) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println("Get Prncipal:"+memb.getRole() );
        authentication.getName();
        System.out.println("Authenticatioin object :"+authentication);
        System.out.println("Authentciation usename:"+authentication.getName());
        System.out.println("Authentication authorities :"+authentication.getAuthorities());
        System.out.println("Authenycaion Principal :"+authentication.getPrincipal());
        System.out.println("Authienctiaytion :"+authentication.getCredentials()+"\n"+"Class :"+authentication.getClass()+"\n"+"Details"+authentication.getDetails());

        Member member=memberRepository.findByName(authentication.getName());
        System.out.println("Mmeber:"+member);
        System.out.println("====Member Details===");
        System.out.println(member.getId()+"/n"+member.getAge()+"/n"+member.getPlayingRole()+"/n"+member.getStatus());


        //here we have to get userdetails once authenticated and get by username details form the reposeitry

        return memberService.findMmemberById(2);
    }


    // getting details by name by PLAYER, STAFF , CHIEF
    @GetMapping("/player/get/name/{name}") // working
    public ResponseEntity<Member> getMemberByName(@PathVariable String name){
        System.out.println("Path Variable :"+name);
        System.out.println("Controller : Finding user By Name");
        return  memberService.findMemberByName(name);
    }


    @PatchMapping("/player/update/{id}")  // working but no need of sending Id explicitly....need to ,meodify
    public ResponseEntity<Member> updateDetails(@RequestBody Member member,@PathVariable Integer id){
        System.out.println("Member"+member);
        return memberService.updateDetails(id,member);
    }

    @PostMapping("/player/book")
    public ResponseEntity<Booking> booking(@RequestBody Booking booking){
        System.out.println("Booking Details by Player");
        System.out.println(booking.toString());
        Member member=bookingService.getMemberByAuthentication();
        return bookingService.book(member.getId(),booking);
    }

    //need one method so can fetch the authentication object

}

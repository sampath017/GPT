package com.example.SBS_Practice1.controller;

import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.repo.MemberRepository;
import com.example.SBS_Practice1.service.BookingService;
import com.example.SBS_Practice1.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ChiefController {

    @Autowired
    BookingService bookingService;

    @Autowired
    MemberRepository memberRepository;

    @Autowired
    MemberService memberService;

    @GetMapping("/chief/members/get")
    public String getAllMembers(){
        return  "fetching all details by chief";
    }
    @PatchMapping("/chief/player/status/update/{id}")
    public ResponseEntity<Member> select(@PathVariable Integer id, @RequestParam("status") String status){
        // The input through Dto- SelectDto- player id ,name,status
        System.out.println("Status"+status);
        System.out.println("Id"+id);

        return memberService.updateStatus(id,status);
    }

}

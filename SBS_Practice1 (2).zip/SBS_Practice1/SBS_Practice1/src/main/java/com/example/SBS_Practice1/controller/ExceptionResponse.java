package com.example.SBS_Practice1.controller;

import com.example.SBS_Practice1.dto.Error;
import com.example.SBS_Practice1.entity.MemberNotFound;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;

//@RestControllerAdvice
public class ExceptionResponse {

    @ExceptionHandler(UnknownError.class)
    public String handleException(String msg){
        System.out.println("Exception class");
        return msg;

    }
    @ExceptionHandler(MemberNotFound.class)
    public ResponseEntity<?> noProductFound(){

        Error error=new Error(400,"Mmener Not Found",new Date());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }// this one method executed when no Member details found by the Id in memberService.findMmemberById


}

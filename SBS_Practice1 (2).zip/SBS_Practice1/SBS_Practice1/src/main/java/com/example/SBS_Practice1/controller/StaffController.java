package com.example.SBS_Practice1.controller;

import com.example.SBS_Practice1.entity.Booking;
import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.service.BookingService;
import com.example.SBS_Practice1.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StaffController {

    @Autowired
    MemberService memberService;
    @Autowired
    BookingService bookingService;

    @GetMapping("/staff/players/get") // working
    public ResponseEntity<List<Member>> getPlayers(){
        System.out.println("Staff Controller : get all player details by satff");
        return memberService.getAllPlayersDetails();
    }

    @GetMapping("/staff/players/role/get/{roleName}")  // working
    public ResponseEntity<List<Member>> getPlayersByRole(@PathVariable String roleName){
        System.out.println("Staff Controller : Player Role :"+roleName);
        System.out.println(("Staff Controller:  fetching player details by playerRole"));
        return memberService.getPlayerDetailsByPlayerRole(roleName);
    }
    // this should be done in request parameter
    @PatchMapping("/staff/player/update/id/{id}") // success but need another methosd to fetch all the players details by sattsi
    public ResponseEntity<Member> updatePlayerStatus(@PathVariable Integer id,@RequestParam("status") String status) {
        // recieve player name and ID and status
        System.out.println("Status : "+status);
        System.out.println("Idv : "+id);
        String res= "Short listed - status"+id+"/n"+status+"/n"+"Updtaed";
        System.out.println(res);
        return memberService.updateStatus(id,status);
    }

    @GetMapping("/staff/players/get/status")//success
    public ResponseEntity<List<Member>> getPlayersByStatus(@RequestParam("status") String status){
        System.out.println("Status"+status);
        return memberService.findByStatus(status);
    }

    @GetMapping("staff/player/age/get")
    public ResponseEntity<List<Member>> getPlayersByAge(@RequestParam("min") Integer min,@RequestParam("max") Integer max){
        System.out.println("Minimum :"+min);
        System.out.println("Maximum"+max);
        String res= "details fetched for age 19 to 27";
        return memberService.findPlayersByAge(min,max);
    }

    @PostMapping("/staff/book/player/id/{id}")
    public ResponseEntity<Booking> bookingByStaff(@PathVariable Integer id, @RequestBody Booking booking){
        return bookingService.bookByStaff(id,booking);
    }


    @GetMapping("/staff/booking/history")
    public ResponseEntity<List<Booking>> getBookingHistory(){
        return bookingService.findBookingHistory();
    }

}

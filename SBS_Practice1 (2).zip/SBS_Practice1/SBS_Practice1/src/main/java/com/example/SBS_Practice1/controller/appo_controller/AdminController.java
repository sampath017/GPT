package com.example.SBS_Practice1.controller.appo_controller;

import com.example.SBS_Practice1.dto.appUseerDto.AdminDashBoard;
import com.example.SBS_Practice1.entity.appEntity.BookAppointment;
import com.example.SBS_Practice1.repo.appRepo.AppointmentRepo;
import com.example.SBS_Practice1.service.appUserService.BookAppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
public class AdminController {

    @Autowired
    BookAppointmentService bookAppointmentService;

    @Autowired
    AppointmentRepo appointmentRepo;

    @PatchMapping("/api/appointments/{id}/status")// we recive the status values
    public ResponseEntity<?> updateStatus(@RequestBody BookAppointment bookAppointment, @PathVariable Long id){
        System.out.println("Status :"+bookAppointment.getStatus());
        return bookAppointmentService.updateStatusForPatient(bookAppointment,id);
    }

    @DeleteMapping("/api/appointments/delete/{id}")
            public ResponseEntity<?> deleteAppointment(@PathVariable Long id){
        return bookAppointmentService.delete(id);
    }

    @GetMapping("/api/doctors/{doctorId}/appointments")
    public ResponseEntity<?> getAllAppointmentsForDoctor(@PathVariable Integer doctorId){

        return bookAppointmentService.ListAllAppointmentsForDoctor(doctorId);
    }

    @GetMapping("/api/patients/{patientId}/appointments")
    public ResponseEntity<?> getAllAppointmentsForPatient(@PathVariable Integer patientId){

        return bookAppointmentService.ListAllAppointmentsForUser(patientId);
    }

    @PreAuthorize("has")
    @GetMapping("/api/admin/dashboard")
    public ResponseEntity<AdminDashBoard> getAdminDashboard(){

        return bookAppointmentService.getAdminDashboard();
    }



}

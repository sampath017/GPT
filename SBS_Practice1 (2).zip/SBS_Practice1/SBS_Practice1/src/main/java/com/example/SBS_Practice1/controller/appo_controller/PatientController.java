package com.example.SBS_Practice1.controller.appo_controller;

import com.example.SBS_Practice1.entity.appEntity.AppUser;
import com.example.SBS_Practice1.entity.appEntity.AppUserDetails;
import com.example.SBS_Practice1.entity.appEntity.BookAppointment;
import com.example.SBS_Practice1.entity.appEntity.BookingStatus;
import com.example.SBS_Practice1.repo.appRepo.AppUserRepo;
import com.example.SBS_Practice1.repo.appRepo.AppointmentRepo;
import com.example.SBS_Practice1.service.appUserService.BookAppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Optional;

@RestController
public class PatientController {

    @Autowired
    AppointmentRepo appointmentRepo;

    @Autowired
    BookAppointmentService bookAppointmentService;

    @Autowired
    AppUserRepo appUserRepo;

    @PostMapping("/api/patient/book/appointment")
    public ResponseEntity<?> bookAppointmentByPatient(@RequestBody BookAppointment bookAppointment, @AuthenticationPrincipal() UserDetails userDetails){
        BookAppointment b=new BookAppointment();
        System.out.println("PatinetController : Userdetails "+userDetails);
       // System.out.println("App Userdetails"+userDetails.getAppUser());
       // AppUser appUser=userDetails.getAppUser();
      //  System.out.println("Patient Controller By Authentication Principal"+appUser.getMobile());
       AppUser appUser=getAuthentication();
        System.out.println("Patient Controller: apuser : fullname"+appUser.getFullName());
        b.setPatientName(appUser.getFullName()); // patient name
        b.setDoctorName(bookAppointment.getDoctorName());
        b.setAppointmentDate(bookAppointment.getAppointmentDate());
        b.setStatus(BookingStatus.SCHEDULED);
        b.setCreatedAt(LocalDate.now());
        b.setUpdatedAt(LocalDate.now());


        return bookAppointmentService.saveAppointment(b);
    }

    private AppUser getAuthentication() {
        String principal= (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println("Username "+SecurityContextHolder.getContext().getAuthentication().getPrincipal());

        //UserDetails appUserDetails= (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println("Since as a principal we have added username only");
        System.out.println("Patinet controller :getAuthenticaation : username :Princiapl : "+principal);
        AppUser appUser=appUserRepo.findByUsername(principal);
        System.out.println("Patinet controller :getAuthenticaation : Mobile"+appUser.getMobile());
        return appUser;
    }

}

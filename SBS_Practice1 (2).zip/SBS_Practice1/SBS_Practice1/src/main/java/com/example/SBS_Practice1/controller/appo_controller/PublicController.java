package com.example.SBS_Practice1.controller.appo_controller;

import com.example.SBS_Practice1.dto.Login;
import com.example.SBS_Practice1.dto.LoginResponse;
import com.example.SBS_Practice1.entity.appEntity.AppUser;
import com.example.SBS_Practice1.entity.appEntity.AppUserDetails;
import com.example.SBS_Practice1.entity.appEntity.excpetions.LoginFailedException;
import com.example.SBS_Practice1.entity.appEntity.excpetions.RegistrationFailedException;
import com.example.SBS_Practice1.jwt_service.JwtUtils;
import com.example.SBS_Practice1.repo.appRepo.AppUserRepo;
import com.example.SBS_Practice1.service.appUserService.AppService;
import com.example.SBS_Practice1.service.appUserService.BookAppointmentService;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.event.spi.SaveOrUpdateEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.sound.midi.Soundbank;
import java.time.LocalDate;
import java.util.Date;



@Slf4j
@RestController
public class PublicController {

    @Autowired
    AppService appService;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    AppUserRepo appUserRepo;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    BookAppointmentService bookAppointmentService;

    @PostMapping("/api/appUser/register")
    public ResponseEntity<?> register(@RequestBody AppUser appUser) throws Exception {
        // registration
        System.out.println("Controller : Registration");
        AppUser a = new AppUser();
        try {
            a.setUsername(appUser.getUsername());
            a.setAge(appUser.getAge());
            a.setEmail(appUser.getEmail());
            System.out.println("Before this execution of the PASS");
            a.setPassword(passwordEncoder.encode(appUser.getPassword()));
            a.setGender(appUser.getGender());
            a.setMobile(appUser.getMobile());
            a.setAppoRole(appUser.getAppoRole());
            a.setSpecialization(appUser.getSpecialization());
            a.setFullName(appUser.getFullName());
            a.setCreatedDate(LocalDate.now());
            System.out.println(LocalDate.now());
            a.setUpdatedDate(LocalDate.now());
        } catch (RegistrationFailedException e) {
            System.out.println("In catch blcok : Controller");
            throw new RegistrationFailedException("Registration failed : ");
        }

        return appService.saveUser(a);


    }

    @PostMapping("/api/appUser/login")
    public ResponseEntity<?> login(@RequestBody Login login) {

        System.out.println("Username :" + login.getUsername());
        System.out.println("Password" + login.getPassword());

        LoginResponse loginResponse;
        Authentication authentication;

        try {
            System.out.println("Before authentication");
            authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(login.getUsername(), login.getPassword()));
            System.out.println("After authentciaion");
        } catch (Exception e) {
            throw new LoginFailedException("Login Failed");
        }
        //
        System.out.println("Authnicaition:" + authentication);
        AppUserDetails userDetails = (AppUserDetails) authentication.getPrincipal();
        System.out.println("Authetication Princiapl :" + authentication.getPrincipal());
        System.out.println("Authetication Authorities :" + authentication.getAuthorities());
        System.out.println("Authentication Creadentials :" + authentication.getCredentials());
        AppUser appUser = userDetails.getAppUser();
        System.out.println("AppUser from CustomUserDeatails :" + appUser);
        System.out.println("Userdetails Password :" + userDetails.getPassword());
        System.out.println("Userdetails username :" + userDetails.getUsername());
        System.out.println("AppUser passowrd :" + appUser.getPassword());
        System.out.println("App User :" + appUser.getGender());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtUtils.generateToken(userDetails);
        loginResponse = new LoginResponse();
        loginResponse.setToken(token);
        loginResponse.setStatus("SUCCESSFUL");
        System.out.println("Public controller : Login Successful");
        return new ResponseEntity<>(loginResponse, HttpStatus.OK);

        //login by everyone

    }

    @GetMapping("/api/user/get/{id}")
    public ResponseEntity<AppUser> getUserById(@PathVariable Integer id){
        System.out.println("Controller : Id :"+id);
        return appService.findUserById(id);
    }

    @GetMapping("/api/appintment/get/{id}")
    public ResponseEntity<?> getApppointmentById(@PathVariable Long id){
        return  bookAppointmentService.getById(id);
    }


}



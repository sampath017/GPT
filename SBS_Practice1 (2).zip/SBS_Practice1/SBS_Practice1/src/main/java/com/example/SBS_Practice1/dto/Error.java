package com.example.SBS_Practice1.dto;

import java.util.Date;

public class Error {

    Integer code;

    public Integer getCode() {
        return code;
    }

    public Error() {
    }

    public Error(Integer code, String errorDesc, Date time) {
        this.code = code;
        this.errorDesc = errorDesc;
        this.time = time;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    String errorDesc;
    Date time;
}

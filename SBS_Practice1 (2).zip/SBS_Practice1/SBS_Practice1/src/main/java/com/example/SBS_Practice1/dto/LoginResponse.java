package com.example.SBS_Practice1.dto;

public class LoginResponse {

    String status; // Failed Success

    String token;// Token if Sucess status

    public LoginResponse(String status, String token) {
        this.status = status;
        this.token = token;
    }

    public LoginResponse() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}

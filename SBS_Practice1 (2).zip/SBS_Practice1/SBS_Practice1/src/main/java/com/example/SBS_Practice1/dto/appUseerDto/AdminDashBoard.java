package com.example.SBS_Practice1.dto.appUseerDto;

import com.example.SBS_Practice1.entity.appEntity.BookAppointment;
import lombok.Data;

import java.util.List;

@Data
public class AdminDashBoard {
    long totalUser;
    long totalAppointments;
    List<BookAppointment> listByStatus;

}

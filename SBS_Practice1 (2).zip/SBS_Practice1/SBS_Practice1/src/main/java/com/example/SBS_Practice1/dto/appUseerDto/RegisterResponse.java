package com.example.SBS_Practice1.dto.appUseerDto;

import com.example.SBS_Practice1.entity.appEntity.AppoRole;
import lombok.Data;

@Data
public class RegisterResponse {
    public Integer userId;
    String username;

    public RegisterResponse(Integer id, String username, String fullName, String email, String mobile, AppoRole role) {
        this.userId = id;
        this.username = username;
        this.fullName = fullName;
        this.email = email;
        this.mobile = mobile;
        this.role = role;
    }

    String fullName;
    String email;
    String mobile;
    AppoRole role;



}

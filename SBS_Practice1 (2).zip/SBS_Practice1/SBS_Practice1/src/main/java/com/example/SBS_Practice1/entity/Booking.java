package com.example.SBS_Practice1.entity;

import jakarta.persistence.*;

@Entity
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;         // generated automaticallly from the system
    @Column(unique = true,nullable = false)
    String slotDetails;   // Slot number availability Day 1 Need another entity...Day 1- 1
    // 2.user can fetch slot deatails available...1.Each user can book ony one slot
    //3.user can select slot and book it. When booking confimred user views booking ID Booking By Booked at should be generated
// user,ground,startsTime,Ed time, Cheif selector, status - confirmed , pending, cancelled

    String bookedBy;

    public String getBookedFor() {
        return bookedFor;
    }

    public void setBookedFor(String bookedFor) {
        this.bookedFor = bookedFor;
    }


    String bookedFor;


    @Override
    public String toString() {
        return "Booking{" +
                "id=" + id +
                ", slotDetails='" + slotDetails + '\'' +
                ", bookedBy='" + bookedBy + '\'' +
                ", bookedFor='" + bookedFor + '\'' +
                ", venue='" + venue + '\'' +
                ", bookingDate='" + bookingDate + '\'' +
                ", BookingStatus='" + BookingStatus + '\'' +
                '}';
    }

    @Column(nullable = false)
    String venue;

    String bookingDate;

    String BookingStatus;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSlotDetails() {
        return slotDetails;
    }

    public void setSlotDetails(String slotDetails) {
        this.slotDetails = slotDetails;
    }

    public String getBookedBy() {
        return bookedBy;
    }

    public void setBookedBy(String bookedBy) {
        this.bookedBy = bookedBy;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getBookingStatus() {
        return BookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        BookingStatus = bookingStatus;
    }

    public Booking(int id, String slotDetails, String bookedBy, String bookedFor, String venue, String bookingDate, String bookingStatus) {
        this.id = id;
        this.slotDetails = slotDetails;
        this.bookedBy = bookedBy;
        this.bookedFor = bookedFor;
        this.venue = venue;
        this.bookingDate = bookingDate;
        BookingStatus = bookingStatus;
    }

    public Booking(){

    }

//
}

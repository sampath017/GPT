package com.example.SBS_Practice1.entity;

public class MemberNotFound extends RuntimeException{

    public  MemberNotFound(String msg){
        super(msg);
    }
}

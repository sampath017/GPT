package com.example.SBS_Practice1.entity;

public enum Role{

    PLAYER,
    STAFF,
    CHIEF
}
package com.example.SBS_Practice1.entity.appEntity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;


@Data
@Entity
public class AppUser {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Integer userId;


   @Column(nullable = false,unique = true,name = "USERNAME")
   private String username;

   @Column(unique = true,nullable = false)
   private  String password;

   @Enumerated(EnumType.STRING)
   private AppoRole appoRole;

   @Column(nullable = false,name = "FULL_NAME")
   private String fullName;


   @Column(name = "AGE",nullable = false)
   private int age;

   @Column(name ="GENDER",nullable = false)
   private String gender;

   @Column(name="MOBILE",nullable = false)
   private String mobile;

   @Column(name="EMAIL")
   private String email;

   @Column(nullable = true)
   private String specialization;


   LocalDate createdDate;

   LocalDate updatedDate;


}

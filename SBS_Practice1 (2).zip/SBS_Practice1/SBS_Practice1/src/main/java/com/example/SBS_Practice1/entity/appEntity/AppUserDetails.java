package com.example.SBS_Practice1.entity.appEntity;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

@Component
public class AppUserDetails implements UserDetails {

  private  AppUser appUser;

    public AppUser getAppUser() {
        return appUser;
    }

    public AppUserDetails(AppUser appUser) {
        this.appUser = appUser;
    }
    public  AppUserDetails(){

    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        ArrayList<SimpleGrantedAuthority> authorities=new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_"+appUser.getAppoRole()));
      //  GrantedAuthority authority=new SimpleGrantedAuthority("ROLE_"+appUser.getAppoRole());
        //authorities.add(authority);


        return authorities;
    }

    @Override
    public String getPassword() {
        return appUser.getPassword();
    }

    @Override
    public String getUsername() {
        return appUser.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return UserDetails.super.isAccountNonExpired();
    }
}

package com.example.SBS_Practice1.entity.appEntity;

public enum AppoRole {

    PATIENT,
    DOCTOR,
    ADMIN
}

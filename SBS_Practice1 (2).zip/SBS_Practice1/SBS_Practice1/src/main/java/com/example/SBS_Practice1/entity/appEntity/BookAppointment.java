package com.example.SBS_Practice1.entity.appEntity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
@Data
@Entity
public class BookAppointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long id;

    String patientName;
    String doctorName;
    LocalDateTime appointmentDate;
    @Enumerated(EnumType.STRING)
    BookingStatus status; // once this has completed use Enum

    LocalDate createdAt;
    LocalDate updatedAt;


}

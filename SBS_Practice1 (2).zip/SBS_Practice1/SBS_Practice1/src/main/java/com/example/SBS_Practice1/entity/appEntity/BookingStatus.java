package com.example.SBS_Practice1.entity.appEntity;

public enum BookingStatus {

    SCHEDULED,
    CONFIRMED,
    COMPLETED,
    CANCELLED,
    NO_SHOW
}

package com.example.SBS_Practice1.entity.appEntity.excpetions;

import com.example.SBS_Practice1.dto.LoginResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandlerClass {

    @ExceptionHandler(RegistrationFailedException.class)
    public ResponseEntity<?> handleException(){
        System.out.println("The meassage from Excpetion method");
        return  ResponseEntity.badRequest().body("Regsitration failed ");
    }

    @ExceptionHandler(LoginFailedException.class)
    public ResponseEntity<?> loginFailed(){
        LoginResponse loginResponse=new LoginResponse("Token not created","Failed");
        System.out.println("Login Failed : Exceptipon Hanndler");
        return ResponseEntity.badRequest().body(loginResponse);
    }
}

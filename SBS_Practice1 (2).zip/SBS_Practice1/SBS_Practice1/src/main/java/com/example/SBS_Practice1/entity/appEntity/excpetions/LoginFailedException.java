package com.example.SBS_Practice1.entity.appEntity.excpetions;

public class LoginFailedException extends  RuntimeException{
    public LoginFailedException(String message){
        super(message);
    }
}

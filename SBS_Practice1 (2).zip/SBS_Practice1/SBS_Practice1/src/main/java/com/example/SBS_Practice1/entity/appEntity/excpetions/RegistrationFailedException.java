package com.example.SBS_Practice1.entity.appEntity.excpetions;

public class RegistrationFailedException extends RuntimeException{
    public RegistrationFailedException(String message) {
        super(message);
    }
}

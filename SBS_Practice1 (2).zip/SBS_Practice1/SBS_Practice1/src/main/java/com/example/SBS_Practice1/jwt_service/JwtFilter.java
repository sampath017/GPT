package com.example.SBS_Practice1.jwt_service;


import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.entity.appEntity.AppUser;
import com.example.SBS_Practice1.entity.appEntity.AppUserDetails;
import com.example.SBS_Practice1.repo.MemberRepository;
import com.example.SBS_Practice1.repo.appRepo.AppUserRepo;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    JwtUtils jwtUtils;
    @Autowired
    MemberRepository memberRepository;

    @Autowired
    AppUserRepo appUserRepo;
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        String authHeader= request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }
        String token= authHeader.split(" ")[1];
        System.out.println(" Token Fetched from URL: "+token);
        String username=jwtUtils.extractUsername(token);
        System.out.println("Filter :username"+username);

        if(username!= null && SecurityContextHolder.getContext().getAuthentication()==null){
//          //  Member member=memberRepository.findByName(username);
//            System.out.println("Username from DB "+member.getName());
//
//            if(jwtUtils.isValid(member,token)){
//                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(username,null, member.getAuthorities());
//                System.out.println("Get Authorities :"+member.getAuthorities());
//                System.out.println("Token validated");
//                SecurityContextHolder.getContext().setAuthentication(authToken);
//
//
//            }

            AppUser appUser=appUserRepo.findByUsername(username);

            AppUserDetails userDetails=(AppUserDetails) new AppUserDetails(appUser);
            if(jwtUtils.isValid(userDetails,token)){
                UsernamePasswordAuthenticationToken authToke=new UsernamePasswordAuthenticationToken(username,null,userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(authToke);
            }

        }
        System.out.println("Before this filter");
        filterChain.doFilter(request, response);
    }

    public Member getMemberByAuthentication(){
        Authentication authentication=SecurityContextHolder.getContext().getAuthentication();
        Member member=memberRepository.findByName(authentication.getName());
        System.out.println("Member by Authentication :"+member);
        return  member;
    }
}

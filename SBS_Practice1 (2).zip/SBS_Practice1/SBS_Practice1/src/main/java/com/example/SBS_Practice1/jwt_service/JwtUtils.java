package com.example.SBS_Practice1.jwt_service;



import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Date;
@Service
public class JwtUtils {



    private String SECRET_key="sag48jaga124jsujfsffuewowehfjiijas77283iessfs";


    // 5 Methods 1. Generate Token, Parse Token, Validate token

    public String generateToken(UserDetails userDetails){
        return Jwts
                .builder()
                .subject(userDetails.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis()+ 24 * 60* 60* 60 *1000))
                .signWith(getSignKey())
                .compact();
    }



    private SecretKey getSignKey() {
        byte[] key= Decoders.BASE64.decode(SECRET_key);
        return Keys.hmacShaKeyFor(key);
    }


    public Claims extractClaims(String token) {
        return Jwts
                .parser()
                .verifyWith(getSignKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }
    public Date expiraDate(String token) {
        return extractClaims(token).getExpiration();
    }

    public boolean isValid(UserDetails user, String token) {
        return extractUsername(token).equals(user.getUsername()) & expiraDate(token).after(new Date(System.currentTimeMillis()));
    }

}

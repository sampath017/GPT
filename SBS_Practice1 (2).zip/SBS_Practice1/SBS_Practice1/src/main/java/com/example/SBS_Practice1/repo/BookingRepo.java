package com.example.SBS_Practice1.repo;

import com.example.SBS_Practice1.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepo extends JpaRepository<Booking,Integer> {
    Booking findByBookedBy(String name);
}

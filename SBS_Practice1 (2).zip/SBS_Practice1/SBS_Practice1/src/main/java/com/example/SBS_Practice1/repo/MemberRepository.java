package com.example.SBS_Practice1.repo;

import com.example.SBS_Practice1.entity.Member;

import com.example.SBS_Practice1.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface MemberRepository extends JpaRepository<Member,Integer> {
  //  Member findByUsername(String username);


    Member findByName(String username);


    List<Member> findByRole(Role s);

    List<Member> findByRoleAndPlayingRole(Role role, String playerRole);

    List<Member> findByStatus(String status);

    List<Member> findByAgeBetween(Integer min, Integer max);
}

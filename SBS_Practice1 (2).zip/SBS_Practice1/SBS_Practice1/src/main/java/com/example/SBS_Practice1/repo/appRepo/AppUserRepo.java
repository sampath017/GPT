package com.example.SBS_Practice1.repo.appRepo;

import com.example.SBS_Practice1.entity.appEntity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppUserRepo extends JpaRepository<AppUser,Integer> {
    AppUser findByUsername(String username);
}

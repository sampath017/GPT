package com.example.SBS_Practice1.repo.appRepo;

import com.example.SBS_Practice1.entity.appEntity.BookAppointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppointmentRepo extends JpaRepository<BookAppointment,Long> {

    List<BookAppointment> findAllByDoctorName(String fullName);

    List<BookAppointment> findByDoctorName(String fullName);

    List<BookAppointment> findByPatientName(String fullName);

   // List<BookAppointment> findAllOrderByStatusDesc();


    @Query("SELECT b FROM BookAppointment b ORDER BY " +
             "CASE b.status " +
             "WHEN 'SCHEDULED' THEN 1 " +
             "WHEN 'CONFIRMED' THEN 2 " +
             "WHEN 'CANCELLED' THEN 3 " +
             "WHEN 'NO_SHOW' THEN 4 " +
             "END")
    List<BookAppointment> findAllOrderByStatus();

    //  List<BookAppointment> findByStatusOrderByStatus();
}

package com.example.SBS_Practice1.service;

import com.example.SBS_Practice1.entity.Booking;
import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.entity.Role;
import com.example.SBS_Practice1.repo.BookingRepo;
import com.example.SBS_Practice1.repo.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    BookingRepo bookingRepo;

    @Autowired
    MemberRepository memberRepository;

    public ResponseEntity<Booking> book(Integer id, Booking booking) {
        Member member = getMemberByAuthentication();  // who is booking
        System.out.println("Role" + member.getRole());

            if (member.getRole().equals(Role.PLAYER) ||member.getRole().equals(Role.CHIEF) || member.getRole().equals(Role.STAFF)) {
                if (!member.getStatus().equals("SELECTED") && member.getRole().equals(Role.PLAYER) ) {
                  // if player -and not SELECTED status
                    System.out.println("Please contact Chief or wait for until SELCTETION");
                    System.out.println("Member not selected");
                    return new ResponseEntity<>(HttpStatusCode.valueOf(400));
                }

                Booking book = bookingRepo.findByBookedBy(member.getName());
                if ((book == null && member.getRole().equals(Role.PLAYER) || member.getRole().equals(Role.CHIEF) || member.getRole().equals(Role.STAFF)) ) {

                    // continue booking
                    String slotBooking = booking.getSlotDetails();
                    Boolean check=checkSlots(slotBooking);
                    if(check) {

                        Booking b = bookNow(booking, member,id);
                        System.out.println("Booking details :"+b.toString());
                        Booking b1=bookingRepo.save(b);
                        System.out.println("Booked for"+b1.getBookedFor());

                        return new ResponseEntity<>(b1, HttpStatus.OK);
                    }

                }
                else{
                    System.out.println("You have alreadybooked");
                }
            }

            //method to check slot availabiloty

            return new ResponseEntity<>(HttpStatusCode.valueOf(400));
        }

    private Boolean checkSlots(String slotBooking) {

        List<Booking> all = bookingRepo.findAll();
        for (Booking b : all) {
            if (b.getSlotDetails().equals(slotBooking)) {
                System.out.println("Slot already booked sorry try another one");
                return false;
            }
        }
        return true;
    }

    // take booking and member object and do book
    private Booking bookNow(Booking booking, Member member, Integer id) {

        Booking b= new Booking();
        b.setId(booking.getId());
        b.setVenue(booking.getVenue());
        b.setSlotDetails(booking.getSlotDetails());
        b.setBookingDate(String.valueOf(new Date(System.currentTimeMillis())));
        b.setBookedBy(member.getName());

        b.setBookedFor(memberRepository.findById(id).get().getName());
        b.setBookingStatus("BOOKED-Please available on time");
        System.out.println("Slot Booked");
        return  b;
    }

    public Member getMemberByAuthentication(){
        System.out.println("Inside getMemberByAuthentication");
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        Member member=memberRepository.findByName(authentication.getName());
        System.out.println("Member by Authentication :"+member);
        System.out.println("Exit : getMemberByAuthentication");
        return member;

    }


    public ResponseEntity<List<Booking>> findBookingHistory() {
        List<Booking> list=bookingRepo.findAll();

        return  new ResponseEntity<>(list,HttpStatus.OK);
    }


    public ResponseEntity<Booking> bookByStaff(Integer id, Booking booking) {
            Member member=getMemberByAuthentication();
            Optional<Member> memberBookingFor=memberRepository.findById(id);

//       memberBookingFor.ifPresent(member1 ->{
//                // get if any booked for the memberBooked For
//                List<Booking> list=bookingRepo.findAll();
//                String slot=booking.getSlotDetails();
//                Boolean check=checkSlots(slot);
//                Boolean checkForBookedFor=checkBookedFor(member1);
//
//                     if(check){
//                         if(checkForBookedFor){
//                            //book now
//                             bookNow(booking,member,member1.getId());
//
//                         }else{
//                             System.out.println("Already booked");
//
//                         }
//                     }else{
//                         System.out.println("Slots alrady booked");
//
//                     }
//
//                    }
//                    );
        // cannot use return statemnt since ifPresent check fpr voiud -- so getting

        if(memberBookingFor.isPresent()){
            List<Booking> list=bookingRepo.findAll();
                String slot=booking.getSlotDetails();
                Boolean check=checkSlots(slot);
              Boolean checkForBookedFor=checkBookedFor(memberBookingFor.get());

            if(check){
                         if(checkForBookedFor){
                            //book now
                            Booking b= bookNow(booking,member,memberBookingFor.get().getId());
                            memberBookingFor.get().setStatus("SELECTED");
                             return new ResponseEntity<>(bookingRepo.save(b),HttpStatus.CREATED);

                         }else{
                             System.out.println("Already booked for this guy");

                         }
                     }else{
                         System.out.println("same slot Slots already booked");

                     }

        }


            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    private Boolean checkBookedFor(Member memberBookingFor) {
        List<Booking> list=bookingRepo.findAll();
        for(Booking b:list){
            if(b.getBookedFor().equals(memberBookingFor.getName())){
                System.out.println("Already bookings done for this guy : "+memberBookingFor.getName());
                return false;
            }
        }
        return true;
    }
}

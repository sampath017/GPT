package com.example.SBS_Practice1.service;

import com.example.SBS_Practice1.entity.Member;
import com.example.SBS_Practice1.entity.MemberNotFound;
import com.example.SBS_Practice1.entity.Role;
import com.example.SBS_Practice1.repo.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MemberService {
    @Autowired
    MemberRepository memberRepository;

    public ResponseEntity<HashMap<String, String>> save(Member member) {
        //any logic- any memeber validations usppose age here
        HashMap<String, String> regRes = new HashMap<>();

        Member existMember=memberRepository.findByName(member.getName());
        if(existMember!=null){
            regRes.put("Status", "Fialed");
            regRes.put("Reason", "User already registered");
            return new ResponseEntity<>(regRes, HttpStatus.BAD_REQUEST);
        }else{
            System.out.println("Service : Registration ");
                    if(!member.getRole().equals(Role.PLAYER)){
                        member.setStatus("Registered-Active- SELECTOR OR CHIEF");
                    }
            // member.setStatus("Registered-Active- SELECTOR OR CHIEF");
            Member m1 = memberRepository.save(member);
            regRes.put("Status", "Success");
            regRes.put("Name", m1.getName());
            regRes.put("Mmeber status", m1.getStatus());
            return new ResponseEntity<>(regRes, HttpStatus.CREATED);
        }

    }

    public ResponseEntity<List<Member>> findAllMembers() {
        return new ResponseEntity<>(memberRepository.findAll(),HttpStatus.OK);
    }


    public ResponseEntity<Member> findMmemberById(Integer id) {

        if(memberRepository.findById(id).isPresent()){
            System.out.println("===Details for findByIid====");
            System.out.println(memberRepository.findById(id));
            return  new ResponseEntity<Member>(memberRepository.findById(id).get(),HttpStatus.OK);
        }else{
            throw new MemberNotFound("Mmeber by Id Not found");
        }
       // System.out.println("Cannot fetch th details since ID is not prsent");
       // return new ResponseEntity<Member>(HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<Member> updateDetails(Integer id, Member member) {
        if(memberRepository.findById(id).isPresent()){

            Member m=memberRepository.findById(id).get();
            m.setName(member.getName());
            System.out.println("old name"+m.getName());
            System.out.println("New name"+member.getName());
            return new ResponseEntity<Member>(memberRepository.save(m),HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

    }

    //finding members by name
    public ResponseEntity<Member> findMemberByName(String name) {

        if(memberRepository.findByName(name)!=null) {
            System.out.println("===Details for : findByNmae()==");
            System.out.println(memberRepository.findByName(name));
            return new ResponseEntity<Member>(memberRepository.findByName(name),HttpStatus.OK);
        }
        return new ResponseEntity<Member>(HttpStatus.BAD_REQUEST);

    }

    public ResponseEntity<List<Member>> getAllPlayersDetails() {

        //System.out.println("All Player details only"+memberRepository.findByPlayerRole("PLAYER"));

        List<Member> playerList=memberRepository.findByRole(Role.PLAYER);
        System.out.println("===Find By Player role details===");
        System.out.println(playerList);
        if(!memberRepository.findAll().isEmpty()){
            System.out.println("===Service: Finding all players by staff==");
            System.out.println(memberRepository.findAll());
            return new ResponseEntity<>(playerList,HttpStatus.OK);
        }
        System.out.println("Service: No players list so far");
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<List<Member>> getPlayerDetailsByPlayerRole(String playerRole) {

        List<Member> playersList=memberRepository.findByRoleAndPlayingRole(Role.PLAYER,playerRole);
        System.out.println("Fetchong players by ROLE PLAYER and player Role");
        System.out.println(playersList);
        if (playersList==null){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(playersList,HttpStatus.OK);
    }

    public ResponseEntity<Member> updateStatus(Integer id, String status) {
        if(memberRepository.findById(id).isPresent()){
            Member m=memberRepository.findById(id).get();
            System.out.println("Old status"+m.getStatus());
            m.setStatus(status);
            System.out.println("New Status"+m.getStatus());
            System.out.println("You can go for booking");
             return new ResponseEntity<>(memberRepository.save(m),HttpStatus.OK);

        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<List<Member>> findByStatus(String status) {
        List<Member> list=memberRepository.findByStatus(status);
        return new ResponseEntity<>(list,HttpStatus.OK);
    }

    public ResponseEntity<List<Member>> findPlayersByAge(Integer min, Integer max) {
        List<Member> list=memberRepository.findByAgeBetween(min,max);
        return new ResponseEntity<>(list,HttpStatus.OK);
    }
}

package com.example.SBS_Practice1.service.appUserService;

import com.example.SBS_Practice1.dto.appUseerDto.RegisterResponse;
import com.example.SBS_Practice1.entity.appEntity.AppUser;
import com.example.SBS_Practice1.entity.appEntity.excpetions.RegistrationFailedException;
import com.example.SBS_Practice1.repo.appRepo.AppUserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AppService {
    @Autowired
    AppUserRepo appUserRepo;

    public ResponseEntity<?> saveUser(AppUser a) throws Exception {
        System.out.println("App Service :Registration");
        //Validations and condition
        if (appUserRepo.findByUsername(a.getUsername()) == null) {
            System.out.println("checking if user exists with the username");
            //  No user exists with the username
            try {
                System.out.println(" Try block");


               // return new ResponseEntity<>(appUserRepo.save(a), HttpStatus.CREATED);
                AppUser response=appUserRepo.save(a);
                RegisterResponse res=new RegisterResponse(response.getUserId(),response.getUsername(),response.getFullName(),response.getMobile(),response.getEmail(),response.getAppoRole());
                return new ResponseEntity<>(res, HttpStatus.CREATED);
            } catch (Exception e) {
                System.out.println("Registration failed in Catch block");
                throw new RegistrationFailedException("registration failed : From First ");
            }
        } else if (appUserRepo.findByUsername(a.getUsername()) != null) {
            // User already exists-Create a response or Exception to notify the user
            System.out.println("User already exists with the username" + a.getUsername());
            return ResponseEntity.badRequest().body("Username should be unique" + a.getUsername());
        } else {
            System.out.println("Throwing the Registration failed exception");
            throw new RegistrationFailedException("registration failed");
        }

    }

    public ResponseEntity<AppUser> findUserById(Integer id) {
        Optional<AppUser> appUser=appUserRepo.findById(id);
       // return appUser.map(user -> new ResponseEntity<>(user, HttpStatus.OK)).orElseGet(() -> new ResponseEntity<>(HttpStatus.BAD_REQUEST));

        if(appUser.isPresent()){
            return new ResponseEntity<>(appUser.get(),HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
}

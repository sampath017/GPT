package com.example.SBS_Practice1.service.appUserService;

import com.example.SBS_Practice1.dto.appUseerDto.AdminDashBoard;
import com.example.SBS_Practice1.entity.appEntity.AppUser;
import com.example.SBS_Practice1.entity.appEntity.BookAppointment;
import com.example.SBS_Practice1.entity.appEntity.BookingStatus;
import com.example.SBS_Practice1.repo.appRepo.AppUserRepo;
import com.example.SBS_Practice1.repo.appRepo.AppointmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookAppointmentService {

    @Autowired
    AppointmentRepo appointmentRepo;

    @Autowired
    AppUserRepo appUserRepo;


    public ResponseEntity<?> saveAppointment(BookAppointment b) {
         try{
             System.out.println("Saving the appointment");

             return new ResponseEntity<>(appointmentRepo.save(b), HttpStatus.CREATED);
         }catch (Exception e){
             System.out.println(e);
             return ResponseEntity.badRequest().body("Appoointemet failed");
         }
    }

    public ResponseEntity<?> getById(Long id) {

            Optional<BookAppointment> bookAppointment=appointmentRepo.findById(id);
            if(bookAppointment.isPresent()){
                return ResponseEntity.ok().body(bookAppointment);
            }


        return ResponseEntity.badRequest().body("Cannot get Apponitment details");
    }

    public ResponseEntity<?> updateStatusForPatient(BookAppointment bookAppointment, Long id) {
        if(appointmentRepo.findById(id).isPresent()){
            BookAppointment bookAppointment1=appointmentRepo.findById(id).get();
            bookAppointment1.setStatus(bookAppointment.getStatus());
            appointmentRepo.save(bookAppointment1);
            return ResponseEntity.ok().body(bookAppointment1);

        }
        return ResponseEntity.badRequest().body("Update Failed : Cannot find details with the Id"+id);
    }

    public ResponseEntity<?> delete(Long id) {
        if(appointmentRepo.findById(id).isPresent()){
            BookAppointment b=appointmentRepo.findById(id).get();
            b.setStatus(BookingStatus.CANCELLED);
            appointmentRepo.save(b);
            //appointmentRepo.delete(appointmentRepo.findById(id).get());
            return ResponseEntity.ok().body("Appoinmtent cancelled");
        }
        return  ResponseEntity.badRequest().body("Cannot Find details with Id");
    }

    public ResponseEntity<?> ListAllAppointmentsForDoctor(Integer id) {
        if(appUserRepo.findById(id).isPresent()){
            AppUser appUser=appUserRepo.findById(id).get();

            List<BookAppointment> apps=appointmentRepo.findByDoctorName(appUser.getFullName());
            if(apps.isEmpty()){
                return ResponseEntity.ok().body("No Appoinments for Doctor"+appUser.getFullName());
            }
            return ResponseEntity.ok().body(apps);

        }
        return ResponseEntity.badRequest().body("Doctor with no Id");
    }

    public ResponseEntity<?> ListAllAppointmentsForUser(Integer id) {
        if(appUserRepo.findById(id).isPresent()){
            AppUser appUser=appUserRepo.findById(id).get();
            return ResponseEntity.ok().body(appointmentRepo.findByPatientName(appUser.getFullName()));

        }
        return ResponseEntity.badRequest().body("Patient with no Id");
    }

    public ResponseEntity<AdminDashBoard> getAdminDashboard() {
        AdminDashBoard adminDashBoard=new AdminDashBoard();
        long totalUsers=appUserRepo.count();
        long totalAppointments=appointmentRepo.count();
        System.out.println("Total users +"+totalUsers);
        System.out.println("Total apponitmets"+totalAppointments);
        List<BookAppointment> appAll=appointmentRepo.findAll();
        System.out.println("All Appos by findAll() :"+appAll);
      //  List<BookAppointment> appintments= appointmentRepo.findByStatusOrderByStatus();
        System.out.println("Find all and Order by "+appAll);
        List<BookAppointment> listByStatus=appointmentRepo.findAllOrderByStatus();
        System.out.println("Order by Status :"+listByStatus);




        adminDashBoard.setTotalUser(totalUsers);
        adminDashBoard.setTotalAppointments(totalAppointments);
        adminDashBoard.setListByStatus(listByStatus);
        return ResponseEntity.ok().body(adminDashBoard);
    }
}

package com.example.SBS_Practice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbsPractice1Application {

	public static void main(String[] args) {
		SpringApplication.run(SbsPractice1Application.class, args);
	}

}

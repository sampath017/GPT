package com.example.SBS_Practice1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbsPractice1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
